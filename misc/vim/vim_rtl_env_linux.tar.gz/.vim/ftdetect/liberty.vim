scriptencoding utf-8
autocmd BufRead,BufNewFile *.lib set filetype=liberty
