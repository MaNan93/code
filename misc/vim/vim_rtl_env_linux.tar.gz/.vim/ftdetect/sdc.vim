scriptencoding utf-8
autocmd BufRead,BufNewFile *.sdc,*.dc set filetype=sdc
