scriptencoding utf-8
autocmd BufRead,BufNewFile *.upf set filetype=upf
