scriptencoding utf-8
" ============================================================
"  ~/.vim/plugin/comment.vim
"  <F3> 批量添加行注释  |  <F4> 批量取消行注释
" ============================================================
if exists('g:loaded_simple_comment')
  finish
endif
let g:loaded_simple_comment = 1

function! s:GetCommentPrefix() abort
  let l:ft = &filetype
  if l:ft =~# '^\(systemverilog\|verilog\|verilog_systemverilog\|c\|cpp\|java\|javascript\)$'
    return '//'
  elseif l:ft =~# '^\(tcl\|sdc\|upf\|python\|sh\|bash\|zsh\|yaml\|toml\|make\|cmake\)$'
    return '#'
  elseif l:ft ==# 'vim'
    return '"'
  elseif !empty(&commentstring)
    return substitute(&commentstring, '\s*%s.*$', '', '')
  endif
  return '//'
endfunction

function! s:CommentLines() range abort
  let l:prefix = s:GetCommentPrefix()
  let l:esc_prefix = escape(l:prefix, '/\')
  for l:lnum in range(a:firstline, a:lastline)
    let l:line = getline(l:lnum)
    if l:line =~# '^\s*$'
      continue
    endif
    let l:new_line = substitute(l:line, '^\(\s*\)', '\1' . l:esc_prefix . ' ', '')
    call setline(l:lnum, l:new_line)
  endfor
endfunction

function! s:UncommentLines() range abort
  let l:prefix = s:GetCommentPrefix()
  let l:esc_prefix = escape(l:prefix, '/\.*[]^$~')
  for l:lnum in range(a:firstline, a:lastline)
    let l:line = getline(l:lnum)
    let l:new_line = substitute(l:line, '^\(\s*\)' . l:esc_prefix . '\s\?', '\1', '')
    if l:new_line !=# l:line
      call setline(l:lnum, l:new_line)
    endif
  endfor
endfunction

command! -range CommentLines   <line1>,<line2>call s:CommentLines()
command! -range UncommentLines <line1>,<line2>call s:UncommentLines()

nnoremap <silent> <F3> :CommentLines<CR>
xnoremap <silent> <F3> :CommentLines<CR>
nnoremap <silent> <F4> :UncommentLines<CR>
xnoremap <silent> <F4> :UncommentLines<CR>