scriptencoding utf-8
" ============================================================
"  ~/.vim/plugin/copy_path.vim
"  <F9> 复制当前文件的完整绝对路径到系统剪贴板
" ============================================================
if exists('g:loaded_copy_path')
  finish
endif
let g:loaded_copy_path = 1

function! s:CopyFullPath() abort
  let l:path = expand('%:p')
  if empty(l:path)
    echohl WarningMsg
    echo '当前缓冲区尚未保存为文件'
    echohl None
    return
  endif

  let @" = l:path
  silent! let @+ = l:path
  silent! let @* = l:path
  echo '已复制路径: ' . l:path
endfunction

command! CopyPath call s:CopyFullPath()
nnoremap <silent> <F9> :CopyPath<CR>