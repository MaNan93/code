scriptencoding utf-8
if exists('g:loaded_log_filter') | finish | endif
let g:loaded_log_filter = 1

function! s:JumpToSourceLine() abort
  let l:lnum = str2nr(matchstr(getline('.'), '^\s*\zs\d\+\ze:'))
  let l:src_buf = get(b:, 'filter_src_buf', -1)
  if l:lnum <= 0 || !bufexists(l:src_buf) | return | endif
  let l:winid = bufwinid(l:src_buf)
  if l:winid != -1 | call win_gotoid(l:winid) | else | execute 'buffer ' . l:src_buf | endif
  execute l:lnum
  normal! zz
endfunction

function! s:FilterLines(pat) abort
  let l:src_buf = bufnr('%')
  let l:matches = []
  execute 'silent! global/' . escape(a:pat, '/') . '/call add(l:matches, printf("%6d: %s", line("."), getline(".")))'
  if empty(l:matches)
    echohl WarningMsg | echo 'No matches for: ' . a:pat | echohl None
    return
  endif
  vnew
  setlocal buftype=nofile bufhidden=wipe nobuflisted noswapfile nowrap
  let b:filter_src_buf = l:src_buf
  call setline(1, l:matches)
  setlocal nomodifiable
  nnoremap <buffer> <silent> <CR> :call <SID>JumpToSourceLine()<CR>
endfunction

command! -nargs=1 Filter call s:FilterLines(<q-args>)
cnoreabbrev <expr> filter (getcmdtype() ==# ':' && getcmdline() =~# '^filter$') ? 'Filter' : 'filter'
