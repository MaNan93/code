scriptencoding utf-8
if exists('g:loaded_port2signal') | finish | endif
let g:loaded_port2signal = 1

function! s:ConvertPortLine(line) abort
  let l:comment = ''
  let l:code = a:line
  let l:cidx = match(l:code, '//')
  if l:cidx != -1
    let l:comment = strpart(l:code, l:cidx)
    let l:code = strpart(l:code, 0, l:cidx)
  endif
  let l:m = matchlist(l:code, '^\(\s*\)\<\(input\|output\|inout\|ref\)\>\s\+\(.\{-}\)\([,;]\?\)\(\s*\)$')
  if empty(l:m) | return a:line | endif
  let l:target_type = (l:m[2] ==# 'inout') ? 'wire ' : 'logic'
  let l:body = substitute(l:m[3], '^\<\(wire\|logic\|reg\|bit\)\>\s*', '', '')
  let l:end_char = (l:m[4] ==# ',' || l:m[4] ==# '') ? ';' : l:m[4]
  return l:m[1] . l:target_type . ' ' . l:body . l:end_char . l:m[5] . l:comment
endfunction

function! PortToSignal() range abort
  for l:lnum in range(a:firstline, a:lastline)
    let l:old = getline(l:lnum)
    let l:new = s:ConvertPortLine(l:old)
    if l:new !=# l:old | call setline(l:lnum, l:new) | endif
  endfor
endfunction

command! -range Port2Signal <line1>,<line2>call PortToSignal()
xnoremap <silent> <F6> :Port2Signal<CR>
nnoremap <silent> <F6> :Port2Signal<CR>
