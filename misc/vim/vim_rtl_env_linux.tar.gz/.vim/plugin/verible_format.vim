scriptencoding utf-8
" ============================================================
"  verible_format.vim  —  用 verible-verilog-format 格式化 Verilog / SystemVerilog
" ============================================================
if exists('g:loaded_verible_format')
  finish
endif
let g:loaded_verible_format = 1

let s:defaults = {}
call extend(s:defaults, {
      \ 'column_limit': 120,
      \ 'indentation_spaces': 4,
      \ 'line_break_penalty': 2,
      \ 'line_terminator': 'auto',
      \ 'over_column_limit_penalty': 100,
      \ 'wrap_spaces': 4,
      \ })

call extend(s:defaults, {
      \ 'assignment_statement_alignment': 'infer',
      \ 'case_items_alignment': 'align',
      \ 'class_member_variable_alignment': 'infer',
      \ 'distribution_items_alignment': 'align',
      \ 'enum_assignment_statement_alignment': 'infer',
      \ 'formal_parameters_alignment': 'align',
      \ 'module_net_variable_alignment': 'infer',
      \ 'named_parameter_alignment': 'align',
      \ 'named_port_alignment': 'align',
      \ 'parameter_declaration_alignment': 'infer',
      \ 'port_declarations_alignment': 'align',
      \ 'struct_union_members_alignment': 'align',
      \ 'alignment_group_boundary': 'none',
      \ })

call extend(s:defaults, {
      \ 'formal_parameters_indentation': 'indent',
      \ 'named_parameter_indentation': 'indent',
      \ 'named_port_indentation': 'indent',
      \ 'port_declarations_indentation': 'indent',
      \ })

call extend(s:defaults, {
      \ 'class_parameter_space': 0,
      \ 'compact_indexing_and_selections': 1,
      \ 'expand_coverpoints': 0,
      \ 'port_declarations_right_align_packed_dimensions': 1,
      \ 'port_declarations_right_align_unpacked_dimensions': 0,
      \ 'try_wrap_long_lines': 0,
      \ 'wrap_end_else_clauses': 0,
      \ })

call extend(s:defaults, {
      \ 'max_search_states': 100000,
      \ 'verify_convergence': 1,
      \ 'failsafe_success': 0,
      \ })

let s:builtin = {
      \ 'column_limit': 100,
      \ 'indentation_spaces': 2,
      \ 'line_break_penalty': 2,
      \ 'line_terminator': 'auto',
      \ 'over_column_limit_penalty': 100,
      \ 'wrap_spaces': 4,
      \ 'assignment_statement_alignment': 'infer',
      \ 'case_items_alignment': 'infer',
      \ 'class_member_variable_alignment': 'infer',
      \ 'distribution_items_alignment': 'infer',
      \ 'enum_assignment_statement_alignment': 'infer',
      \ 'formal_parameters_alignment': 'infer',
      \ 'module_net_variable_alignment': 'infer',
      \ 'named_parameter_alignment': 'infer',
      \ 'named_port_alignment': 'infer',
      \ 'parameter_declaration_alignment': 'infer',
      \ 'port_declarations_alignment': 'infer',
      \ 'struct_union_members_alignment': 'infer',
      \ 'alignment_group_boundary': 'none',
      \ 'formal_parameters_indentation': 'wrap',
      \ 'named_parameter_indentation': 'wrap',
      \ 'named_port_indentation': 'wrap',
      \ 'port_declarations_indentation': 'wrap',
      \ 'class_parameter_space': 0,
      \ 'compact_indexing_and_selections': 1,
      \ 'expand_coverpoints': 0,
      \ 'port_declarations_right_align_packed_dimensions': 0,
      \ 'port_declarations_right_align_unpacked_dimensions': 0,
      \ 'try_wrap_long_lines': 0,
      \ 'wrap_end_else_clauses': 0,
      \ 'max_search_states': 100000,
      \ 'verify_convergence': 1,
      \ 'failsafe_success': 1,
      \ }

let s:bool_opts = [
      \ 'class_parameter_space', 'compact_indexing_and_selections', 'expand_coverpoints',
      \ 'port_declarations_right_align_packed_dimensions',
      \ 'port_declarations_right_align_unpacked_dimensions',
      \ 'try_wrap_long_lines', 'wrap_end_else_clauses',
      \ 'verify_convergence', 'failsafe_success',
      \ ]

function! s:ToBool(v) abort
  if type(a:v) == type('')
    return index(['true', '1', 'yes', 'on'], tolower(a:v)) >= 0
  endif
  return a:v ? 1 : 0
endfunction

function! s:BuildArgs() abort
  let l:opt = extend(copy(s:defaults), get(g:, 'verible_format_options', {}))
  let l:args = []
  for l:k in sort(keys(l:opt))
    let l:v = l:opt[l:k]
    if type(l:v) == type('') && l:v ==# ''
      continue
    endif
    if l:k ==# 'indentation_spaces' && type(l:v) == type('') && l:v ==# 'shiftwidth'
      let l:v = exists('*shiftwidth') ? shiftwidth() : &shiftwidth
    endif
    let l:isbool = index(s:bool_opts, l:k) >= 0
    if l:isbool
      let l:v = s:ToBool(l:v)
    endif
    let l:base = get(s:builtin, l:k, '')
    if (l:v . '') ==# (l:base . '')
      continue
    endif
    if l:isbool
      call add(l:args, '--' . l:k . '=' . (l:v ? 'true' : 'false'))
    else
      let l:s = l:v . ''
      call add(l:args, '--' . l:k . '=' . (l:s =~# '[^A-Za-z0-9_.,-]' ? shellescape(l:s) : l:s))
    endif
  endfor
  return join(l:args, ' ')
endfunction

function! s:VeribleFormat(first, last) abort
  let l:bin = get(g:, 'verible_format_bin', '')
  if empty(l:bin)
    let l:local = expand('~/.local/bin/verible-verilog-format')
    let l:bin = executable(l:local) ? l:local : 'verible-verilog-format'
  endif
  if !executable(l:bin)
    echohl ErrorMsg | echomsg '[F5] 找不到 ' . l:bin . '，请检查 PATH 或设置 g:verible_format_bin' | echohl None
    return
  endif
  let l:exe  = exepath(l:bin)
  let l:cmd  = shellescape(empty(l:exe) ? l:bin : l:exe)
  let l:opts = s:BuildArgs()
  if !empty(l:opts) | let l:cmd .= ' ' . l:opts | endif
  let l:extra = get(g:, 'verible_format_args', '')
  if !empty(l:extra) | let l:cmd .= ' ' . l:extra | endif
  if !(a:first == 1 && a:last == line('$'))
    let l:cmd .= ' --lines=' . a:first . '-' . a:last
  endif
  let l:errf = tempname()
  let l:cmd .= ' 2>' . shellescape(l:errf) . ' -'

  let l:src = getline(1, '$')
  let l:save = {}
  if has('unix') && executable('/bin/sh')
    let l:save = {'shell': &shell, 'shellcmdflag': &shellcmdflag, 'shellredir': &shellredir}
    set shell=/bin/sh shellcmdflag=-c shellredir=>%s\ 2>&1
  endif
  let l:t0  = reltime()
  let l:out = systemlist(l:cmd, l:src)
  let l:err = v:shell_error
  let l:secs = reltimefloat(reltime(l:t0))
  if !empty(l:save)
    let &shell = l:save.shell
    let &shellcmdflag = l:save.shellcmdflag
    let &shellredir = l:save.shellredir
  endif
  let l:errlines = filereadable(l:errf) ? readfile(l:errf) : []
  call delete(l:errf)

  if l:err != 0 || !empty(l:errlines)
    echohl ErrorMsg
    echomsg '[F5] 格式化失败（可能有语法错误），buffer 未改动'
    echohl None
    for l:line in (empty(l:errlines) ? l:out : l:errlines)[:4]
      echomsg l:line
    endfor
    echomsg '[F5] 命令: ' . l:cmd
    return
  endif
  call map(l:out, 'substitute(v:val, "\r$", "", "")')
  if l:out ==# l:src
    echomsg printf('[F5] 已经是格式化后的样子（verible 耗时 %.2f 秒）', l:secs)
    return
  endif

  let l:view = winsaveview()
  call setline(1, l:out)
  if len(l:out) < line('$')
    silent execute (len(l:out) + 1) . ', _'
  endif
  call winrestview(l:view)
  echomsg printf('[F5] 格式化完成（verible 耗时 %.2f 秒）', l:secs)
endfunction

function! s:Setup() abort
  let l:key = get(g:, 'verible_format_map', '<F5>')
  execute 'nnoremap <buffer> <silent> ' . l:key . ' :call <SID>VeribleFormat(1, line("$"))<CR>'
  execute 'xnoremap <buffer> <silent> ' . l:key . ' :<C-u>call <SID>VeribleFormat(line("' . "'<" . '"), line("' . "'>" . '"))<CR>'
endfunction

augroup verible_format
  autocmd!
  autocmd BufRead,BufNewFile *.sv,*.svh,*.svi setlocal filetype=systemverilog
  autocmd BufRead,BufNewFile *.v,*.vh         setlocal filetype=verilog
  autocmd FileType systemverilog,verilog,verilog_systemverilog call s:Setup()
augroup END