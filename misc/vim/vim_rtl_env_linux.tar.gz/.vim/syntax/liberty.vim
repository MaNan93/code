scriptencoding utf-8
if exists("b:current_syntax") | finish | endif
syntax case match
syntax region libertyComment start="/\*" end="\*/" contains=@Spell
syntax match  libertyComment "//.*$"
syntax region libertyString start=+"+ skip=+\\"+ end=+"+
syntax match libertyPreProc "^\s*`\(include\|define\|ifdef\|ifndef\|else\|endif\).*$"
syntax match libertyEscape  "\\$"
syntax keyword libertyGroup library cell pin bus bundle ff latch statetable timing internal_power leakage_power power_lut_template lu_table_template cell_rise cell_fall rise_transition fall_transition rise_constraint fall_constraint retaining_rise retaining_fall output_current_rise output_current_fall receiver_capacitance operating_conditions wire_load wire_load_selection type pg_pin test_cell memory memory_read memory_write
syntax keyword libertyAttr direction function three_state next_state clocked_on clear preset related_pin related_pg_pin timing_type timing_sense when sdf_cond area capacitance rise_capacitance fall_capacitance max_capacitance min_capacitance max_transition min_transition fanout_load max_fanout delay_model time_unit voltage_unit current_unit pulling_resistance_unit leakage_power_unit capacitive_load_unit nom_process nom_temperature nom_voltage default_fanout_load default_inout_pin_cap default_input_pin_cap default_output_pin_cap dont_touch dont_use pad_cell is_macro_cell clock_gating_integrated_cell pg_type voltage_name values index_1 index_2 index_3 variable_1 variable_2 variable_3
syntax keyword libertyConst true false input output inout internal combinational rising_edge falling_edge preset clear positive_unate negative_unate non_unate setup_rising setup_falling hold_rising hold_falling recovery_rising recovery_falling removal_rising removal_falling primary_power primary_ground backup_power internal_power
syntax match libertyNumber "\<\d\+\(\.\d\+\)\?\([eE][+-]\?\d\+\)\?\>"
syntax match libertyNumber "[-+]\d\+\(\.\d\+\)\?\([eE][+-]\?\d\+\)\?\>"
highlight default link libertyComment Comment
highlight default link libertyString  String
highlight default link libertyPreProc PreProc
highlight default link libertyEscape  Special
highlight default link libertyGroup   Statement
highlight default link libertyAttr    Type
highlight default link libertyConst   Constant
highlight default link libertyNumber  Number
let b:current_syntax = "liberty"
