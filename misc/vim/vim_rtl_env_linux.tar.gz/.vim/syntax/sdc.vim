scriptencoding utf-8
if exists("b:current_syntax") | finish | endif
runtime! syntax/tcl.vim
unlet! b:current_syntax
syntax keyword sdcClockCmd create_clock create_generated_clock set_clock_groups set_clock_latency set_clock_uncertainty set_clock_transition set_propagated_clock set_ideal_network set_ideal_latency set_ideal_transition set_clock_gating_check set_sense set_clock_sense
syntax keyword sdcIoCmd set_input_delay set_output_delay set_driving_cell set_drive set_load set_port_fanout_number set_fanout_load set_input_transition
syntax keyword sdcExceptionCmd set_false_path set_multicycle_path set_max_delay set_min_delay group_path set_path_margin
syntax keyword sdcEnvCmd set_max_transition set_max_capacitance set_min_capacitance set_max_fanout set_max_area set_case_analysis set_disable_timing set_operating_conditions set_wire_load_model set_wire_load_mode set_wire_load_selection_group set_units set_hierarchy_separator set_dont_touch set_dont_use set_size_only
syntax keyword sdcQueryCmd get_clocks get_ports get_pins get_cells get_nets get_libs get_lib_cells get_lib_pins all_clocks all_inputs all_outputs all_registers all_fanin all_fanout current_design current_instance get_attribute set_attribute sizeof_collection filter_collection add_to_collection remove_from_collection
syntax keyword sdcDcCmd set_app_var define_design_lib analyze elaborate link uniquify check_design check_timing compile compile_ultra optimize_registers set_fix_multiple_port_nets set_boundary_optimization set_ungroup set_clock_gating_style insert_clock_gating report_timing report_area report_power report_qor report_constraint write_file write_sdc
syntax match sdcOption "\s-\a[a-zA-Z0-9_]*\>"
highlight default link sdcClockCmd     Statement
highlight default link sdcIoCmd        Type
highlight default link sdcExceptionCmd Special
highlight default link sdcEnvCmd       PreProc
highlight default link sdcQueryCmd     Function
highlight default link sdcDcCmd        Function
highlight default link sdcOption       Constant
let b:current_syntax = "sdc"
