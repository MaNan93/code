scriptencoding utf-8
if exists("b:current_syntax") | finish | endif
runtime! syntax/tcl.vim
unlet! b:current_syntax
syntax keyword upfDomainCmd create_power_domain set_scope upf_version load_upf save_upf
syntax keyword upfSupplyCmd create_supply_port create_supply_net create_supply_set connect_supply_net connect_supply_set set_domain_supply_net associate_supply_set set_equivalent add_port_state add_power_state
syntax keyword upfSwitchCmd create_power_switch map_power_switch
syntax keyword upfIsoCmd set_isolation set_isolation_control map_isolation_cell
syntax keyword upfLsCmd set_level_shifter map_level_shifter_cell
syntax keyword upfRetCmd set_retention set_retention_control map_retention_cell set_repeater map_repeater_cell
syntax keyword upfPstCmd create_pst add_pst_state set_sim_corruption_mode set_design_attributes set_port_attributes query_upf find_objects
syntax match upfOption "\s-\a[a-zA-Z0-9_]*\>"
highlight default link upfDomainCmd Statement
highlight default link upfSupplyCmd Type
highlight default link upfSwitchCmd PreProc
highlight default link upfIsoCmd    Special
highlight default link upfLsCmd     Special
highlight default link upfRetCmd    Identifier
highlight default link upfPstCmd    Function
highlight default link upfOption    Constant
let b:current_syntax = "upf"
