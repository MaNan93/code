source ~/.vim/vimrc.vim
